# Bollinger - Reentrada confirmada SELL — GBPUSD H1

- Estrategia T-Lab: **#787**
- Workflow: **#359**
- Cuenta permitida: **sólo DEMO**
- IA incluida: Consejero, Rey de Entradas y Rey de Cierres (ONNX)
- IS: **2016-01-01 → 2026-09-07**
- OOS: **2016-01-01 → 2026-09-10 (solapado)**
- Prueba MAIN MT5: PF **2.77**, beneficio neto **753.82**, drawdown **3.17%**, floating máximo **224.36**, **221** trades, win rate **79.19%**

Los resultados son históricos y no garantizan resultados futuros. Cuando el OOS
comienza en 2016, se solapa con IS y no constituye una validación cronológica independiente.
Consulte `INSTALACION.txt` y `SHA256.txt` antes de instalar.
