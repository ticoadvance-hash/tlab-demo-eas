# Barrido de rango de sesión SELL — GBPUSD H1

- Estrategia T-Lab: **#728**
- Workflow: **#352**
- Cuenta permitida: **sólo DEMO**
- IA incluida: Consejero, Rey de Entradas y Rey de Cierres (ONNX)
- IS: **2016-01-01 → 2026-09-07**
- OOS: **No configurado**
- Prueba MAIN MT5: PF **7.28**, beneficio neto **675.08**, drawdown **1.07%**, floating máximo **115.35**, **210** trades, win rate **88.57%**

Los resultados son históricos y no garantizan resultados futuros. Cuando el OOS
comienza en 2016, se solapa con IS y no constituye una validación cronológica independiente.
Consulte `INSTALACION.txt` y `SHA256.txt` antes de instalar.
