# Reversión a VWAP BUY — XTIUSD H1

- Estrategia T-Lab: **#44**
- Workflow: **#335**
- Cuenta permitida: **sólo DEMO**
- IA incluida: Consejero, Rey de Entradas y Rey de Cierres (ONNX)
- IS: **2016-01-01 → 2026-09-07**
- OOS: **No configurado**
- Prueba MAIN MT5: PF **5.14**, beneficio neto **3974.75**, drawdown **6.48%**, floating máximo **809.78**, **430** trades, win rate **87.21%**

Los resultados son históricos y no garantizan resultados futuros. Cuando el OOS
comienza en 2016, se solapa con IS y no constituye una validación cronológica independiente.
Consulte `INSTALACION.txt` y `SHA256.txt` antes de instalar.
