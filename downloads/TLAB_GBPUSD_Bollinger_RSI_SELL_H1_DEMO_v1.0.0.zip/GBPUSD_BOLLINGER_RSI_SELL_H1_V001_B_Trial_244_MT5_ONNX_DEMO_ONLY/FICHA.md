# Bollinger + RSI SELL — GBPUSD H1

- Estrategia T-Lab: **#212**
- Workflow: **#341**
- Cuenta permitida: **sólo DEMO**
- IA incluida: Consejero, Rey de Entradas y Rey de Cierres (ONNX)
- IS: **2016-01-01 → 2026-09-07**
- OOS: **No configurado**
- Prueba MAIN MT5: PF **7.20**, beneficio neto **1045.65**, drawdown **3.45%**, floating máximo **327.43**, **262** trades, win rate **92.75%**

Los resultados son históricos y no garantizan resultados futuros. Cuando el OOS
comienza en 2016, se solapa con IS y no constituye una validación cronológica independiente.
Consulte `INSTALACION.txt` y `SHA256.txt` antes de instalar.
