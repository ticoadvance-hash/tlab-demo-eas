﻿$ErrorActionPreference = "Stop"
$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifestPath = Join-Path $packageRoot "manifest.json"
if (!(Test-Path -LiteralPath $manifestPath)) { throw "No se encontro manifest.json." }
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json

$ex5Path = Join-Path $packageRoot ([string]$manifest.ex5)
if (!(Test-Path -LiteralPath $ex5Path)) { throw "No se encontro el EA compilado: $($manifest.ex5)" }
$onnxRoot = Join-Path $packageRoot "onnx"
$models = @(Get-ChildItem -LiteralPath $onnxRoot -Filter "*.onnx" -File)
if ($models.Count -eq 0) { throw "El paquete no contiene modelos ONNX." }

$commonRoot = Join-Path $env:APPDATA "MetaQuotes\Terminal\Common\Files"
$modelTarget = Join-Path $commonRoot ([string]$manifest.common_files_folder)
New-Item -ItemType Directory -Path $modelTarget -Force | Out-Null
foreach ($model in $models) {
    Copy-Item -LiteralPath $model.FullName -Destination (Join-Path $modelTarget $model.Name) -Force
}

$terminalRoots = @()
$roaming = Join-Path $env:APPDATA "MetaQuotes\Terminal"
if (Test-Path -LiteralPath $roaming) {
    $terminalRoots += Get-ChildItem -LiteralPath $roaming -Directory | Where-Object {
        $_.Name -ne "Common" -and (Test-Path -LiteralPath (Join-Path $_.FullName "MQL5\Experts"))
    } | ForEach-Object { $_.FullName }
}
if (Test-Path -LiteralPath "C:\T_LAB\TERMINALES") {
    $terminalRoots += Get-ChildItem -LiteralPath "C:\T_LAB\TERMINALES" -Directory | Where-Object {
        Test-Path -LiteralPath (Join-Path $_.FullName "MQL5\Experts")
    } | ForEach-Object { $_.FullName }
}
$terminalRoots = @($terminalRoots | Sort-Object -Unique)
if ($terminalRoots.Count -eq 0) {
    $manual = Read-Host "Ruta de la terminal portable (carpeta que contiene terminal64.exe)"
    if (!$manual -or !(Test-Path -LiteralPath (Join-Path $manual "terminal64.exe"))) {
        throw "Ruta de terminal no valida."
    }
    $terminalRoots = @($manual)
}

foreach ($terminalRoot in $terminalRoots) {
    $expertRoot = Join-Path $terminalRoot "MQL5\Experts\T-Lab"
    New-Item -ItemType Directory -Path $expertRoot -Force | Out-Null
    Copy-Item -LiteralPath $ex5Path -Destination (Join-Path $expertRoot ([IO.Path]::GetFileName($ex5Path))) -Force
    Write-Host "EA instalado en: $expertRoot" -ForegroundColor Cyan
}
Write-Host "ONNX instalados en: $modelTarget" -ForegroundColor Green
Write-Host "Instalacion completa. Reinicie MT5 o actualice el Navegador." -ForegroundColor Green
Write-Host "Este EA funciona exclusivamente en cuentas DEMO." -ForegroundColor Yellow
