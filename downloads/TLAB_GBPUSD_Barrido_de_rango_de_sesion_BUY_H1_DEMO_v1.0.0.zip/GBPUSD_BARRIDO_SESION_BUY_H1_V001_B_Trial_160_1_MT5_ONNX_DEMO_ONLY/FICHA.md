# Barrido de rango de sesión BUY — GBPUSD H1

- Estrategia T-Lab: **#754**
- Workflow: **#372**
- Cuenta permitida: **sólo DEMO**
- IA incluida: Consejero, Rey de Entradas y Rey de Cierres (ONNX)
- IS: **2016-01-01 → 2026-09-07**
- OOS: **2016-01-01 → 2026-09-10 (solapado)**
- Prueba MAIN MT5: PF **2.11**, beneficio neto **981.53**, drawdown **9.09%**, floating máximo **996.56**, **269** trades, win rate **80.67%**

Los resultados son históricos y no garantizan resultados futuros. Cuando el OOS
comienza en 2016, se solapa con IS y no constituye una validación cronológica independiente.
Consulte `INSTALACION.txt` y `SHA256.txt` antes de instalar.
