# Ruptura Donchian SELL — GBPUSD H1

- Estrategia T-Lab: **#840**
- Workflow: **#374**
- Cuenta permitida: **sólo DEMO**
- IA incluida: Consejero, Rey de Entradas y Rey de Cierres (ONNX)
- IS: **2016-01-01 → 2026-09-07**
- OOS: **2016-01-01 → 2026-09-10 (solapado)**
- Prueba MAIN MT5: PF **2.35**, beneficio neto **1218.63**, drawdown **6.95%**, floating máximo **787.95**, **240** trades, win rate **72.50%**

Los resultados son históricos y no garantizan resultados futuros. Cuando el OOS
comienza en 2016, se solapa con IS y no constituye una validación cronológica independiente.
Consulte `INSTALACION.txt` y `SHA256.txt` antes de instalar.
