# Bollinger + RSI BUY — GBPUSD H1

- Estrategia T-Lab: **#492**
- Workflow: **#346**
- Cuenta permitida: **sólo DEMO**
- IA incluida: Consejero, Rey de Entradas y Rey de Cierres (ONNX)
- IS: **2016-01-01 → 2026-09-07**
- OOS: **No configurado**
- Prueba MAIN MT5: PF **2.52**, beneficio neto **991.70**, drawdown **6.68%**, floating máximo **771.16**, **415** trades, win rate **88.67%**

Los resultados son históricos y no garantizan resultados futuros. Cuando el OOS
comienza en 2016, se solapa con IS y no constituye una validación cronológica independiente.
Consulte `INSTALACION.txt` y `SHA256.txt` antes de instalar.
