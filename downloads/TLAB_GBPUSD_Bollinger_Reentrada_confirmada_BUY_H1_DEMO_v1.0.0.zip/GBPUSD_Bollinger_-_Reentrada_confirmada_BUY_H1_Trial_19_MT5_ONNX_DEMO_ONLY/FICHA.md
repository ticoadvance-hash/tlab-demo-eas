# Bollinger - Reentrada confirmada BUY — GBPUSD H1

- Estrategia T-Lab: **#755**
- Workflow: **#363**
- Cuenta permitida: **sólo DEMO**
- IA incluida: Consejero, Rey de Entradas y Rey de Cierres (ONNX)
- IS: **2016-01-01 → 2026-09-07**
- OOS: **2016-01-01 → 2026-09-10 (solapado)**
- Prueba MAIN MT5: PF **2.38**, beneficio neto **1103.55**, drawdown **7.75%**, floating máximo **844.95**, **232** trades, win rate **78.45%**

Los resultados son históricos y no garantizan resultados futuros. Cuando el OOS
comienza en 2016, se solapa con IS y no constituye una validación cronológica independiente.
Consulte `INSTALACION.txt` y `SHA256.txt` antes de instalar.
