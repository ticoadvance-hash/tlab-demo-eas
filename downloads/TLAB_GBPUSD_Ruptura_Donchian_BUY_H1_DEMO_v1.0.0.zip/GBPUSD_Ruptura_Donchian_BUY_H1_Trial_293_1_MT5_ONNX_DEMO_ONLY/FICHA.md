# Ruptura Donchian BUY — GBPUSD H1

- Estrategia T-Lab: **#878**
- Workflow: **#376**
- Cuenta permitida: **sólo DEMO**
- IA incluida: Consejero, Rey de Entradas y Rey de Cierres (ONNX)
- IS: **2016-01-01 → 2026-09-07**
- OOS: **2016-01-01 → 2026-09-10 (solapado)**
- Prueba MAIN MT5: PF **2.56**, beneficio neto **1047.12**, drawdown **2.05%**, floating máximo **217.73**, **337** trades, win rate **68.25%**

Los resultados son históricos y no garantizan resultados futuros. Cuando el OOS
comienza en 2016, se solapa con IS y no constituye una validación cronológica independiente.
Consulte `INSTALACION.txt` y `SHA256.txt` antes de instalar.
