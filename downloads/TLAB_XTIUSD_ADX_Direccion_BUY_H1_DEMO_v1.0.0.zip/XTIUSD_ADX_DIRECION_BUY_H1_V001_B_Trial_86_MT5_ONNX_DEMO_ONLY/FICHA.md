# ADX + Dirección BUY — XTIUSD H1

- Estrategia T-Lab: **#25**
- Workflow: **#320**
- Cuenta permitida: **sólo DEMO**
- IA incluida: Consejero, Rey de Entradas y Rey de Cierres (ONNX)
- IS: **2016-01-01 → 2024-12-31**
- OOS: **No configurado**
- Prueba MAIN MT5: PF **6.91**, beneficio neto **7034.07**, drawdown **7.96%**, floating máximo **839.90**, **473** trades, win rate **67.86%**

Los resultados son históricos y no garantizan resultados futuros. Cuando el OOS
comienza en 2016, se solapa con IS y no constituye una validación cronológica independiente.
Consulte `INSTALACION.txt` y `SHA256.txt` antes de instalar.
